$(".alert").fadeOut(8000);
